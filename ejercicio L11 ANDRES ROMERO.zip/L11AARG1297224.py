print("SEMANA 11 ACTIVIDAD 2: Andrés Romero 1297224 ")

N = int(input("Ingrese un número entero mayor a 0 para N: "))
while N <= 0:
    N = int(input("El número debe ser mayor a 0. Por favor, ingrese nuevamente: "))

# Serie a
suma_serie_a = 0
contador = 1
while contador <= N:
    suma_serie_a += 1 / contador
    contador += 1
print("Resultado de la serie a: " + str(suma_serie_a))

# Serie b
suma_serie_b = 0
contador = 1
while contador <= N:
    suma_serie_b += 1 / (2 ** contador)
contador += 1
print("Resultado de la serie b: " + str(suma_serie_b))

# Serie c, solicitar valores adicionales
x = int(input("Ingrese un número entero para x: "))
a = int(input("Ingrese un número entero para a: "))
n = int(input("Ingrese un número entero para n (que actuará como el límite de la sumatoria): "))

suma_serie_c = 0
k = 0
while k <= n:
    # Para calcular el coeficiente binomial de manera básica y principiante:
    # Calcular factorial de n
    factorial_n = 1
    i = n
    while i > 1:
        factorial_n *= i
        i -= 1

    # Calcular factorial de k
    factorial_k = 1
    i = k
    while i > 1:
        factorial_k *= i
        i -= 1
 # Calcular factorial de (n-k)
    factorial_n_k = 1
    i = n - k
    while i > 1:
        factorial_n_k *= i
        i -= 1

    coef_binomial = factorial_n / (factorial_k * factorial_n_k)
    
    # Sumatoria de la serie c
    suma_serie_c += coef_binomial * (x ** k) * (a ** (n - k))
    k += 1

print("Resultado de la serie c: " + str(suma_serie_c))

